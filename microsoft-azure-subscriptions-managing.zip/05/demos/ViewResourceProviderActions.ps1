﻿#Login-AzureRMAccount

Get-AzureRmProviderOperation -OperationSearchString "Microsoft.Compute/*/action"
